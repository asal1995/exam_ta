
from django.views.decorators.csrf import csrf_exempt
import json
from django.http.response import JsonResponse
from msg_app.models import user,note

@csrf_exempt
def Creat_User(request):
   
    if request.method=='POST':
        data=json.loads(request.body)
        if 'username' not in data or 'password' not in data :
            return JsonResponse({'status':'error','msg':'Enter username ,password,'},status=403)
        else:
            username=data.get('username','')
            password=data.get('password','')
        
            current=user.objects.create(username=username, password=password)


        return JsonResponse({'status':'successfull','msg':'user created.'},status=201)
    else:
        return JsonResponse({'status':'error','msg':'method must be post'},status=403)

@csrf_exempt
def create_msg(request,id):
    if request.method=='POST':
        myuser=user.objects.get(id=id)
        data=json.loads(request.body)
        if myuser:
            if 'title' in data and 'text' in data:
                n_title=data.get('title', '')
                n_text=data.get('text','')
                curentnote=note.objects.create(title=n_title,text=n_text , user_id=myuser)
                mynote=user.objects.get(pk=id).mynote
                return JsonResponse({'status':'successfull','msg':'msg created'})
            else:
                JsonResponse({'status':'error','msg':'shalqam note o title ro benevis'})
        else:
            JsonResponse({'status':'error','msg':'shalqam user o password ro benevis'})
    else:
        return JsonResponse({'status':'error','msg':'method must be post'},status=403)
 

@csrf_exempt
def send_msg(request ,user_id ,title):
  
    if request.method=='POST':
        me=request.user.id
        target=user.objects.get(id=user_id)
        cr_note=note.objects.get(title=title)
        if target and cr_note:
            if cr_note.user_id==me:
                new_ms=note.objects.create(title=cr_note.title,text=cr_note.text,user_id=user_id)

                return JsonResponse({'status':'successfull','msg':'new msg'})

            else:
                return JsonResponse({'status':'error','msg':'this is not your msg'})
        else:
             return JsonResponse({'status':'error'})
    
    else:
        return JsonResponse({'status':'error','msg':'method must be post'},status=403)
        

@csrf_exempt
def delet_Msg(requset , title):
    if requset.method=='POST':

        de_note=note.objects.get(title=title)
        if de_note:
            de_note.delet()
            return JsonResponse ({'status':'successfull','msg':'msg deleted'})
        else:
            return JsonResponse ({'status':'error','msg':'not exist'})
    return({'status':'error','msg':'method must be post'})



        






    

            
            
            


      

    



