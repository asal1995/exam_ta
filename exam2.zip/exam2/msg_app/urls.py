
from django.contrib import admin
from django.urls import path
from .views import Creat_User, create_msg, delet_Msg, send_msg

urlpatterns = [
    path('cu/',Creat_User ,name='createuser'),
    path('cm/<str:id>',create_msg ,name='createmsg'),
    path('sm/<str:user_id>/<str:title>',send_msg ,name='send_msg'),
    path('dm/<str:title>',delet_Msg ,name='deletmsg')
]


