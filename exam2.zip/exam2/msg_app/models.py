from django.db import models

from django.contrib.auth.models import User

class user(User):
    mynote=models.JSONField( null=True,blank=True)
    shared_user=models.ManyToManyField('self')
    received=models.JSONField( null=True,blank=True)
    def __str__(self) -> str:
        return f"{self.mynote} {self.received}"



class note(models.Model):
    title=models.CharField(max_length=250)
    text=models.TextField()
    user_id=models.ForeignKey(user,on_delete=models.CASCADE,null=True) 


    def __str__(self) -> str:
        return f"{self.title} {self.text}"
    


