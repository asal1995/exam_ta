from django.contrib import admin

from msg_app.models import note, user


admin.site.register(user)
admin.site.register(note)